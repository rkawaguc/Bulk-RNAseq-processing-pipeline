#!/bin/bash
#SBATCH -c 6
#SBATCH --mem 10G
#SBATCH --export=ALL

#source /u/local/Modules/default/init/modules.sh
ref=$1
out=$2

echo Begin: `date` 1>&2
echo -e gene'\t'$out > $out.count.txt
/share/apps/samtools/base/1.10/bin/samtools view -Sh Aligned.out.sam |/share/apps/anaconda3/2020.07/envs/HTSeq/bin/htseq-count -m intersection-nonempty -s 'no' - $ref 2> $out.count.error.log >> $out.count.txt
echo count table for $sample complete `date` 1>&2



