#!/bin/bash
#SBATCH -c 6
#SBATCH --mem 50G
#SBATCH --export=ALL


## Riki Kawaguchi modified on 08/08/14 originally from Neelroop Pariksha
## added mm39, Riki Kawaguchi modified on 08/08/14 originally from Neelroop Pariksha
## This script submit a signle bam or sam file (aligned via STAR program) in the current folder 
## Output is written  in QC folder 
## first qrugment is either usually Aligned.out.sam or Aligned.out.bam
## secpmd argument is either mm9 or mm10 etc.
## third arugment is whether if you want to keep reordered_reads.sorted.bam default=n

TIMESTAMP=$(date +%m%d%y%H%M%S)
                
## Set locations for .jar files
code=/coppolalabshares/amrf/RNAseq-tools/picard-tools-1.118

## First, find the Aligned.out.sam file
bfile=$1
genome=$2
keep=${3:-"n"}
workingdir=$PWD
bamdir=$workingdir

case "$genome" in
	"mm10RPL22") echo "Will use mm10_RPL22 genome.";
                refgenome=/coppolalabshares/amrf/Genome_data/STAR_genome/mm10_RPL22HA/mm10_RPL22HA.fa;
                refFlat=/coppolalabshares/amrf/Genome_data/Mus_musculus_mm10/UCSC/mm10/refFlat/mm10Pred_RPL22.refFlat;;
	"mm10td") echo "Will use mm10_tdTomato genome.";
                refgenome=/coppolalabshares/amrf/Genome_data/STAR_genome/mm10_tdTomato/mm10_tdTomato.fa;
                refFlat=/coppolalabshares/amrf/Genome_data/STAR_genome/mm10_tdTomato/mm10Pred_tdTomato.refFlat;;
	"mm10") echo "Will use mm10 genome.";
		refgenome=/coppolalabshares/amrf/Genome_data/STAR_genome/ENSEMBL.mus_musculus.release-75/Mus_musculus.GRCm38.75.dna.primary_assembly.fa;
		refFlat=/coppolalabshares/amrf/Genome_data/Mus_musculus_mm10/UCSC/mm10/refFlat/mm10Pred.refFlat;;
	"mm39") echo "Will use mm39 genome.";
		refgenome=/geschwindlabshares/fygaoprj06/RNAseq/GenomeMM39/Mus_musculus.GRCm39.dna_sm.primary_assembly.fa;
		refFlat=/geschwindlabshares/fygaoprj06/RNAseq/GenomeMM39/MM39_add1.refFlat;;
	"mm9") echo "Will use mm9 genome";
		refgenome=/coppolalabshares/amrf/Genome_data/Mus_musculus_mm9/UCSC/mm9/Sequence/WholeGenomeFasta/genome.fa;
		refFlat=/coppolalabshares/amrf/Genome_data/Mus_musculus_mm9/UCSC/mm9/refFlat/mm9Pred.refFlat;;
	"hg38") echo "Will use hg38 genome";
		refgenome=/coppolalabshares/amrf/Genome_data/STAR_genome/Human_GRCh38/Homo_sapiens.GRCh38.dna.primary_assembly.fa;
		refFlat=/coppolalabshares/amrf/Genome_data/GRCh38/GRCh38_hg38-2.refFlat;;
	"hg19") echo "Will use hg37/Hg19 genome";
		refgenome=/coppolalabshares/amrf/Genome_data/STAR_genome/Genome_hg19/Homo_sapiens.GRCh37.75.dna.primary_assembly_simple.fa;
		refFlat=/coppolalabshares/amrf/Genome_data/Hg19_GRCh37/UCSC/noChr/UCSC_hg19.refFlat;;
	"hg19_tophat") echo "Will use hg37/Hg19 genome";
                refgenome=/coppolalabshares/amrf/Genome_data/STAR_genome/Genome_hg19/MTisM/Homo_sapiens.GRCh37.75.dna.primary_assembly_M.fa;
                refFlat=/coppolalabshares/amrf/Genome_data/Hg19_GRCh37/UCSC/UCSC_hg19.refFlat;;
       "mmul") echo "Will use Mmul genome";
                refgenome=/home/fygao/genome/Maccaca_2023_picard/Macaca_mulatta.Mmul_10.dna.toplevel.fa;
                refFlat=/home/fygao/genome/Maccaca_2023_picard/UCSC_rheMac10.refFlat;;
       "mfas") echo "Will use Mfas genome Ensembl refFlat";
                refgenome=/home/fygao/genome/Macaca_fascicularis_picard/Macaca_fascicularis.Macaca_fascicularis_6.0.dna.toplevel.fa;
                refFlat=/home/fygao/genome/Macaca_fascicularis_picard/Macaca_fascicularis_add1.refFlat;;
	"rn5_EGFP") echo "Will use rn5 genome";
                refgenome=/coppolalabshares/amrf/Genome_data/STAR_genome/Rat_rn5/EGFPadded/rn5_plus_EGFP.fa;
                refFlat=/coppolalabshares/amrf/Genome_data/Rat_Rn5/withEGFP/Rn5_EGFP.refFlat;;
	"rn5") echo "Will use rn5 genome";
                refgenome=/coppolalabshares/amrf/Genome_data/STAR_genome/Rat_rn5/rn5.fa;
                refFlat=/coppolalabshares/amrf/Genome_data/Rat_Rn5/Rn5.refFlat;;
	"rn6") echo "Will use rn6 genome";
		refgenome=/home/fygao/genome/rn6_picard/Rattus_norvegicus.Rnor_6.0.dna.toplevel.fa;
		refFlat=/home/fygao/genome/rn6_picard/Rattus_norvegicus_add1.refFlat;;
	*) echo "The genome specified is not supported";;
esac

bfile1=$(basename $bfile)
bfile=${bfile}
echo Current directory is $workingdir
echo Using $bfile as input
if [ -d QC ]; then
	ls ${bamdir}/QC
	if [ `ls ${workingdir}/QC/*log|wc -l` -gt 0 ];then
		echo "Removing old error and out file...."
		rm ${workingdir}/QC/error*
		rm ${workingdir}/QC/out*
  	fi
	if [ -f ${workingdir}/QC/alignment_stats.txt ] && [ -f ${workingdir}/QC/rnaseq_stats.txt ] && [ -f ${workingdir}/QC/gcbias_stats.txt ] && [ -f ${workingdir}/QC/gcbias_summary.txt ] && [ -f ${workingdir}/QC/duplication_stats.txt ] ;then
		echo "Results file already exist. Do you want to erase? [y/n]"
		read answer
		if [ $answer == "y" ];then 
			ls ${workingdir}/QC
			rm ${workingdir}/QC/alignment_stats.txt
			rm ${workingdir}/QC/rnaseq_stats.txt
			rm ${workingdir}/QC/gcbias_stats.txt
			rm ${workingdir}/QC/gcbias_summary.txt
			rm ${workingdir}/QC/duplication_stats.txt
			rm ${workingdir}/QC/duplication_stats.txt
			rm ${workingdir}/QC/insertSizeHist.txt
			echo "removing result files....."
			ls ${workingdir}/QC
		else
			exit
		fi
	fi

	if [ -e ${workingdir}/QC/reordered_reads.sorted.bam ] ;then
		echo "reordered_reads.sorted.bam already exists."
		echo "Do you want to use this file? [y/n]"
		read answer
		case "$answer" in
			"n") rm ${workingdir}/QC/reordered_reads.sorted.bam
		esac
	fi
else 
	echo "Creating QC directory..."
	mkdir ${workingdir}/QC
fi

echo $PATH
echo $bfile 
echo $bamdir 
echo $workingdir 
echo $refgenome 
echo $refFlat 
echo $keep

sbatch -c 6 --mem 50G, -o ${workingdir}/QC/out_${TIMESTAMP}.log -e ${workingdir}/QC/error_${TIMESTAMP}.log ${code}/../RunPicardScripts_test.sh ${PATH} ${bfile} ${bamdir} ${workingdir} ${refgenome} ${refFlat} ${keep}

exit

